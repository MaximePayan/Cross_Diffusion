function [Pp] = polynomial_derivative(P)
d = length(P);
if d<=1
    Pp = 0;
else
    Pp = (1:d-1).*P(2:d);
end
end

