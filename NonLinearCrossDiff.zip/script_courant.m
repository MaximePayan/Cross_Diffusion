%% End Point by Newton's Method
for i=1:length(I0053bis)
point_test = I0053bis(i);
U = UU(2:end,point_test);
% sigma = UU(1,point_test);
sigma = 0.053;
N = 50;
N_out = 150;

U = [U(1:N); zeros(N_out-N,1); U(N+1:2*N);zeros(N_out-N,1)]; 
% figure(1)
% clf(1,'reset')
% plot_cos(U(1:N_out),a,b,100,'r--',1)    
% hold on
% plot_cos(U(N_out+1:2*N_out),a,b,100,'b',1)
% xlabel('$x$', 'Interpreter', 'latex')
% legend('u','v')
% title('Starting Point')
% set(gca,'FontSize',20)
% axis square

it_max = 200;
tol = 10^-12;
K=30;
F_DF = @(X) F_DF_diffusion_croise(X,a,b,sigma,eps,nu,func_opt,which_gamma,K);
[U_refine,E] = func_Newton(U,F_DF,it_max,tol);

% figure(2)
% clf(2,'reset')
% plot_cos(U_refine(1:N_out),a,b,200,'r--',2)
% hold on
% plot_cos(U_refine(N_out+1:2*N_out),a,b,200,'b',2)
% xlabel('$x$', 'Interpreter', 'latex',Position=[4.52,0.7,-0.1],Units='data')
% legend('u','v')
% %title("End Point")
% subtitle("u(0)="+num2str(UU0(point_test)))
% set(gca,'FontSize',20)
% axis square

% figure(3)
% clf(3,'reset')
% loglog(E(1:length(E)-1),E(2:length(E)),'bo')
% hold on
% loglog(E,E,'r--')
% loglog(E,E.^2,'g--')
% loglog(E,E.^3,'c--')
% 
% xlabel('e_n')
% ylabel('e_{n+1}')
% legend('Error','Linear','Quadratic','Cubic')
% title("Convergence of the error in Newton's method")


r=1e-8;
tic
DK = 2*N_out;
step_2_proof
toc
end
%%
FU = F_DF(U);
FU_refine = F_DF(U_refine);
disp(norm(FU))
disp(norm(FU_refine))
[F_ext2, ~, ~] = F_DF_D2F(u,v,gammav,gammapv,gammappv,N,N_out,a,b,sigma,eps);
disp(norm(F_ext))
disp(norm(F_ext2))
%%
[gv,gpv,gppv,gpppv,~,~,~,~] = transform_gamma(v,nu,func_opt,which_gamma,N,N_out,K);
disp(norm(gv-gammav))
disp(norm(gpv-gammapv))
disp(norm(gppv-gammappv))
disp(norm(gpppv-gammapppv))
%%
Sigma = UU(1,1:end);
UU0 = UU(2,:)+2*sum(UU(3:N+1,:),1);
figure(1)
clf(1,'reset')
plot(Sigma,UU0,'b.',Sigma(point_test),UU0(point_test),'ko',MarkerSize=10,LineWidth=3)
xlabel('\sigma','Rotation',0,'FontSize',18,'VerticalAlignment','bottom');
ylabel('u(0)','Rotation',0,'FontSize',18,'VerticalAlignment','cap');
legend('numerical solution','point test')
title('Etats stationnaires obtenus par continuation numérique','FontSize',20)
%%
figure(2)
clf(2,'reset')
surf(abs(B'))
%%
figure(3)
clf(3,'reset')
surf(abs(A'))
%%
figure(4)
clf(4,'reset')
surf(abs(DF_ext'))
%% 
%Ifind =find(abs(Sigma-0.055) < 6e-4 & abs(UU0-0.644)<6e-4);
figure(2)
clf(2,'reset')
I0053bis = I0053([1 3 5 7 16 17]);
plot(Sigma,UU0,'b.',Sigma(I0053bis),UU0(I0053bis),'ko',MarkerSize=10,LineWidth=3)
xlabel('\sigma','Rotation',0,'FontSize',18,'VerticalAlignment','bottom');
ylabel('u(0)','Rotation',0,'FontSize',18,'VerticalAlignment','cap');
legend('numerical solution','point test')
title('Etats stationnaires obtenus par continuation numérique','FontSize',20)
%%

K=30;
point_test = Ifind(2);
ds=3.6e-2;
itmax=300;
p=1;

func_G_DG = @(U_tilde,U1,V1,s) G_DG(U_tilde,U1,V1,a,b,eps,nu,s,func_opt,which_gamma,K);
Up=UU(:,point_test);
Vp = (UU(:,point_test+1)-Up)/ds;
%Vp(1)=1;
% [~,DGUp] = func_G_DG(Up,Up,Vp,ds);
% M=length(DGUp);
% [~,~,B] = svd(DGUp(2:M,:));
% Vp = B(:,M);
Bifbranch2 = [Up];

tic
[Ubranch2,it,Bifbranch2]=func_test_continuation_bis(Up,Vp,ds,func_G_DG,p,itmax,0,Bifbranch2);
toc
save('data_frac_2_mode_2.mat','Ubranch2','point_test','Bifbranch2')
%%
Sigmabranch2 = Ubranch2(1,:);
Ubranch2_0 = Ubranch2(2,:)+2*sum(Ubranch2(3:N+1,:),1);
figure(3)
clf(3,'reset')
plot(Sigma,UU0,'b.',Sigmabranch2,Ubranch2_0,'c.',MarkerSize=10,LineWidth=3)
xlabel('\sigma','Rotation',0,'FontSize',18,'VerticalAlignment','bottom');
ylabel('u(0)','Rotation',0,'FontSize',18,'VerticalAlignment','cap');
legend('numerical solution','point test')
title('Etats stationnaires obtenus par continuation numérique','FontSize',20)
%%
UU = [UU,Ubranch2];
Bifurcations = [Bifurcations,Bifbranch2];