%%
% Initialisation of the data
a = 0; b=4*pi; %boundary of the segment
eps = 0.1; %diffusion rate of the species
sigma = 0.25; %logistic parameter
l = b-a;
N = 50; %size of vectors for the Newton's Method
N_out = 100; %size of vectors for the validation
DK = 2*N_out; %size of the offset for the build of the A matrix
r = 1e-10; %default radius to validate the numerical solution
nu = 1.0001; %parameter of the norm

%%
% Choice of the function gamma
%%
% Example 1/(1+x^9) (rationnal fraction)
P=zeros(1,2);P(1)=1;Q=zeros(1,10);Q(1)=1;Q(10)=1;
gfr = @(x) g_frac(x,P,Q);
    Pp = polynomial_derivative(P);
    Qp = polynomial_derivative(Q);
    Pnum1 = conv(Pp,Q) - conv(P,Qp);
    Pden1 = conv(Q,Q);
gfrp = @(x) g_frac(x,Pnum1,Pden1);
    Pnum1p = polynomial_derivative(Pnum1);
    Pden1p = polynomial_derivative(Pden1);
    Pnum2 = conv(Pnum1p,Pden1) - conv(Pnum1,Pden1p);
    Pden2 = conv(Pden1,Pden1);
gfrpp =  @(x) g_frac(x,Pnum2,Pden2);
    Pnum2p = polynomial_derivative(Pnum2);
    Pden2p = polynomial_derivative(Pden2);
    Pnum3 = conv(Pnum2p,Pden2) - conv(Pnum2,Pden2p);
    Pden3 = conv(Pden2,Pden2);
gfrppp =  @(x) g_frac(x,Pnum3,Pden3);

frac_opt={gfr gfrp gfrpp gfrppp P Q};

clear Pnum1 Pnum2 Pnum3 Pden1 Pden2 Pden3 Pnum1p Pnum2p Pden1p Pden2p Pp Qp
clear gfr gfrp gfrpp gfrppp P Q
%%
% Example exp(-alpha*x)
alpha = -3;
gexp = @(x) g_exp(alpha,x);
gexpp = @(x) alpha*gexp(x);
gexppp = @(x) alpha*gexpp(x);
gexpppp = @(x) alpha*gexppp(x);

exp_opt = {gexp gexpp gexppp gexpppp alpha};
clear alpha gexp gexpp gexppp gexpppp
%%
% Starting Point and Computations on stability
func_opt = exp_opt; which_gamma = 'exp';
%canditate for stability and default initiliazed vector :
U=zeros(2*N+1,1);U(1)=1;U(N+1)=1;
perturb = 1e-3; %value of the perturbation arround the default
% be careful func_approche_syst gives information on the stability of the
% state (1,1) nothing else
U = func_approche_syst(a,b,sigma,eps,func_opt{1},func_opt{2},N,perturb);

clear exp_opt frac_opt
%save('initialized_data.mat','U','a','b','eps','sigma','l','N','nu','func_opt','which_gamma');