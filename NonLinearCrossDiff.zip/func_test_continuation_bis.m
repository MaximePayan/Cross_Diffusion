function [UU,it,Bifurc] = func_test_continuation_bis(U,V,ds,G_DG,p,itmax,it,Bifurc)
%FUNC_TEST_CONTINUATION Explore the map of zeros
%G_DG is a function which takes Upp,Up,Vp in argue
%Up is an approx zero, Vp is the direction of exploration
%ds the step, p the depth, itmax max iteration
UU=[];
Up=U;
Vp=V;
tol=1e-12;
it_max=20;
while it< itmax && Up(1)>1e-8 && Up(1)<1
        Upp = Up+ds*Vp;
        [Upp,~] = func_Newton(Upp,@(X) G_DG(X,Up,Vp,ds),it_max,tol);
        [~,DGUp] = G_DG(Up,Up,Vp,ds);
        [~,DGUpp] = G_DG(Upp,Upp,Vp,ds);
        M=length(DGUp);
        [~,~,B] = svd(DGUpp(2:M,:));
        %Bifurc = Bifurc(vecnorm(Bifurc(2:end,:),2,1)<20);
        if det(DGUp)*det(DGUpp)<0 && p>1 && ...
                isempty(find(vecnorm(Bifurc-Upp,2,1)<2*ds, 1))
            Bifurc = [Bifurc,Upp];
            Vpp = B(:,M-1);
            [UUwest,it1,Bifurc1] = func_test_continuation_bis(Up,Vpp,ds,G_DG,p-1,itmax,it,Bifurc);
            Bifurc = Bifurc1;
            UU=[UU,UUwest];
            [UUeast,it2,Bifurc2] = func_test_continuation_bis(Up,-Vpp,ds,G_DG,p-1,itmax,it,Bifurc);
            Bifurc = Bifurc2;
            UU=[UU,UUeast];
            [UUnorth,it3,Bifurc3] = func_test_continuation_bis(Upp,Vp,ds,G_DG,p,itmax,it,Bifurc);
            Bifurc = Bifurc3;
            it = it1+it2+it3-2*it;
            UU=[UU,UUnorth];
        end
        Vpp = B(:,M);
        if Vp'*Vpp<0
            Vp=-Vpp;
        else
            Vp=Vpp;
        end
        Up=Upp;
        UU=[UU,Up];
        it=it+1;
end
end

