r=1e-8;
G0 = [];
G1 = [];
G2 = [];
G3 = [];
for i=1:length(UU)
    v = UU(N+2:2*N+1,i);
    [gv,gpv,gppv,gpppv,~,~,~,~]=transform_gamma(v,nu,func_opt,which_gamma,N,N,K);
    G0=[G0,local_bound_on_gamma(v,r,func_opt,which_gamma,0,nu)];
    G1=[G1,local_bound_on_gamma(v,r,func_opt,which_gamma,1,nu)];
    G2=[G2,local_bound_on_gamma(v,r,func_opt,which_gamma,2,nu)];
    G3=[G3,local_bound_on_gamma(v,r,func_opt,which_gamma,3,nu)];
end

%%
V0 = UU(N+2,:) + 2*sum(UU(N+3:2*N+1,:),1);
semilogy(V0,G0,LineStyle="none",Marker=".");
hold on
semilogy(V0,G1,LineStyle="none",Marker="+");
hold on
semilogy(V0,G2,LineStyle="none",Marker="*");
hold on
semilogy(V0,G3,LineStyle="none",Marker="x");
legend("G0","G1","G2","G3")
%%
normV = vecnorm(UU(2:2*N+1,:),0.1,1);
semilogy(normV,G0,LineStyle="none",Marker=".");
hold on
semilogy(normV,G1,LineStyle="none",Marker="+");
hold on
semilogy(normV,G2,LineStyle="none",Marker="*");
hold on
semilogy(normV,G3,LineStyle="none",Marker="x");
legend("G0","G1","G2","G3")