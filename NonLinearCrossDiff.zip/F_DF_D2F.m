function [F,DF,D2F] = F_DF_D2F(u,v,gv,gpv,gppv,N,D,a,b,sigma,eps)
%use uniquely in the computation of the constants
%becarefull here u is size D but F1 is size 2D
l = b-a;
if exist('intval','file')
    Lap = intval(laplacien(D,l));
    I = intval(eye(D));
    eps = intval(eps);
    sigma = intval(sigma);
    
else
    Lap = laplacien(D,l);
    I = eye(D);
end


Mu = convomat(u,D); %size DxD
Mgv = convomat(gv,D);
Mgpv = convomat(gpv,D);
uu = Mu*[u ; zeros(D-N,1)]; 
ugv = Mu*[gv;zeros(D-N,1)];


F1 = Lap.*ugv + sigma*([u;zeros(D-N,1)]-uu); %size D
F2 = eps*Lap.*[v;zeros(D-N,1)] + [u-v;zeros(D-N,1)]; %size D

F = [F1;F2]; %size 2D

DF = [diag(Lap)*Mgv + sigma*(I-2*Mu), diag(Lap)*Mgpv*Mu;
    I, eps*diag(Lap)-I]; %size 2Dx2D

D2F = [2*sigma*[u;zeros(D-N,1)],[gpv;zeros(D-N,1)];[gpv;zeros(D-N,1)],convo(gppv,u,D)];
%size  2Dx2
%that is not exactly D^2F but just what is needed to compute Z2 
end
