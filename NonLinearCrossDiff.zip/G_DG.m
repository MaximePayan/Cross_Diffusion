function [Y,DY] = G_DG(U_tilde,Up,Vp,a,b,eps,nu,ds,func_opt,which_gamma,K)
%U_tilde=[sigma;U], G=[_,F_tilde] where F_tilde is F depending of sigma,U
M=length(U_tilde);

%M must be odd else error rises in F_DF_diffusion_croise, M=2*N+1
[y,duy] = F_DF_diffusion_croise(U_tilde(2:M),a,b,U_tilde(1),eps,nu,func_opt,which_gamma,K);
%duy = diff of F_tilde with respect to U = U_tilde(2:N) 
Y=zeros(M,1);
DY=zeros(M,M);
Y(1)=(U_tilde-(Up+ds.*Vp))'*Vp;
Y(2:M)=y;
DY(1,:)=Vp';
dsigmay=zeros(M-1,1);
u=U_tilde(2:(M-1)/2+1);
dsigmay(1:(M-1)/2)= u -convo(u,u); 
%dsigmay = diff of F_tilde with respect to sigma = U_tilde(1)
DY(2:M,:)=[dsigmay duy];
end