function [gammav,gammapv,gammappv,gammapppv,errgammav,errgammapv,errgammappv,errgammapppv] = transform_gamma(v,nu,func_opt,which_gamma,N,N_out,K)
if which_gamma == "frac_2"
    which_gamma = "frac";
end
switch which_gamma
    case 'exp'
        d = K*(N-1)+1;
        d = max([d N_out]);
        normev=norme_nu(v,nu);
        alpha = func_opt{end};
        if nargout > 2
            errgammav = abs(alpha)*normev*func_opt{1}(-normev);
        end
        one = zeros(d,1);
        one(1) = 1;
        raison_gammav = alpha*v;
        term_gammav = one;
        gammav = term_gammav;
        for i=1:K
            term_gammav = convo(term_gammav,raison_gammav,d);
            if nargout > 2
                errgammav = errgammav*abs(alpha)*normev/(i+1);
            end
            gammav = gammav+term_gammav;
            raison_gammav = alpha*v/(i+1);
        end
        temp = gammav;
        gammav = temp(1:N_out);
        gammapv = alpha*gammav;

        if nargout > 2
            errgammav = errgammav + norme_nu(temp(N_out+1:end),nu);
            gammappv = alpha*gammapv;
            gammapppv = alpha*gammappv;
            errgammapv = abs(alpha)*errgammav;
            errgammappv = abs(alpha)*errgammapv;
            errgammapppv = abs(alpha)*errgammappv;
        end

    case 'frac'
        P=func_opt{end-1};Q=func_opt{end};
        d1 = (max([length(P) length(Q)])-1)*(N-1)+1;
        d1 = max([d1 N_out]);
        one1 = zeros(d1,1);
        one1(1)=1;
        [Pv,Qv]=vectors_PvQv(v,P,Q,d1);
        inv_Qv = convomat(Qv)\one1;
        
        temp1 = convo(Pv,inv_Qv,d1);
        gammav = temp1(1:N_out);
        
        Pp = polynomial_derivative(P);
        Qp = polynomial_derivative(Q);
        Pnum = conv(Pp,Q) - conv(P,Qp);
        Pden = conv(Q,Q);
        d2 = (max([length(Pnum) length(Pden)])-1)*(N-1)+1;
        [Pnumv,Pdenv]=vectors_PvQv(v,Pnum,Pden,d2);
        one2 = zeros(d2,1);
        one2(1)=1;
        inv_Pdenv = convomat(Pdenv)\one2;
        temp2 = convo(Pnumv,inv_Pdenv,d2);
        gammapv = temp2(1:N_out);

        if nargout > 2
            err1 = norme_nu(convo(Qv,inv_Qv)-one1,nu); %it must be smaller than 1
            errgammav =  err1/(1-err1)*norme_nu(Pv,nu)*norme_nu(inv_Qv,nu);
            errgammav = errgammav + norme_nu(temp1(N_out+1:end),nu);

            err2 = norme_nu(convo(Pdenv,inv_Pdenv)-one2,nu); %it must be smaller than 1
            errgammapv =  err2/(1-err2)*norme_nu(Pnumv,nu)*norme_nu(inv_Pdenv,nu);
            errgammapv = errgammapv + norme_nu(temp2(N_out+1:end),nu);

            Ppp = polynomial_derivative(Pp);
            Qpp = polynomial_derivative(Qp);
            Q2 = conv(Q,Q);
            Qp2 = conv(Qp,Qp);
            Pnum1 = conv(Ppp,Q2); 
            Pnum21 = 2*conv(Pp,Qp); Pnum22 = conv(P,Qpp);
            n2 = max([length(Pnum21) length(Pnum22)]);
            Pnum2 = -conv(Q,[Pnum21,zeros(n2-length(Pnum21),1)]+[Pnum22,zeros(n2-length(Pnum22),1)]);
            Pnum3 = 2*conv(P,Qp2);
            n = max([length(Pnum1) length(Pnum2) length(Pnum3)]);
            Pnum = [Pnum1,zeros(1,n-length(Pnum1))]+[Pnum2,zeros(1,n-length(Pnum2))]...
                +[Pnum3,zeros(1,n-length(Pnum3))];
            Pden = conv(Q2,Q);
            d3 = (max([length(Pnum) length(Pden)])-1)*(N-1)+1;

            [Pnumv,Pdenv]=vectors_PvQv(v,Pnum,Pden,d3);
            one3 = zeros(d3,1);
            one3(1)=1;
            inv_Pdenv = convomat(Pdenv)\one3;
            temp3 =  convo(Pnumv,inv_Pdenv,d3);
            gammappv = temp3(1:N_out);
            err3 = norme_nu(convo(Pdenv,inv_Pdenv)-one3,nu); %it must be smaller than 1
            errgammappv =  err3/(1-err3)*norme_nu(Pnumv,nu)*norme_nu(inv_Pdenv,nu);
            errgammappv = errgammappv + norme_nu(temp3(N_out+1:end),nu);

            Pppp = polynomial_derivative(Ppp);
            Qppp = polynomial_derivative(Qpp);
            Q3 = conv(Q2,Q);
            Qp3 = conv(Qp2,Qp);
            Pnum1 = conv(Pppp,Q3);
            Pnum2 = 6*conv(conv(Q,Qp),conv(Pp,Qp)+conv(P,Qpp));
            Pnum31 = 3*conv(Ppp,Qp);
            Pnum32 = 3*conv(Pp,Qpp);
            Pnum33 = conv(P,Qppp);
            n3 = max([length(Pnum31) length(Pnum32) length(Pnum33)]);
            Pnum3 = -conv(Q2,[Pnum31,zeros(1,n3-length(Pnum31))]+[Pnum32,zeros(1,n3-length(Pnum32))]...
                +[Pnum33,zeros(1,n3-length(Pnum33))]);
            Pnum4 = -6*conv(P,Qp3);
            n = max([length(Pnum1) length(Pnum2) length(Pnum3) length(Pnum4)]);
            Pnum = [Pnum1,zeros(1,n-length(Pnum1))]+[Pnum2,zeros(1,n-length(Pnum2))]...
            +[Pnum3,zeros(1,n-length(Pnum3))]+[Pnum4,zeros(1,n-length(Pnum4))];
            Pden = conv(Q3,Q);

            d4 = (max([length(Pnum) length(Pden)])-1)*(N-1)+1;
            [Pnumv,Pdenv]=vectors_PvQv(v,Pnum,Pden,d4);
            one4 = zeros(d4,1);
            one4(1)=1;
            inv_Pdenv = convomat(Pdenv)\one4;
            temp4 = convo(Pnumv,inv_Pdenv,d4);
            gammapppv = temp4(1:N_out);
            err4 = norme_nu(convo(Pdenv,inv_Pdenv)-one4,nu); %it must be smaller than 1
            errgammapppv = err4/(1-err4)*norme_nu(Pnumv,nu)*norme_nu(inv_Pdenv,nu);
            errgammapppv = errgammapppv + norme_nu(temp4(N_out+1:end),nu);
        end

    otherwise
        if nargout==2
            [gammav,gammapv] = transforme(v,func_opt{3},func_opt{4},func_opt{1},func_opt{2},N_out);
        else
        error("Sorry but there are just the cases where which_gamma is 'exp' or 'frac'")
        end
end
end