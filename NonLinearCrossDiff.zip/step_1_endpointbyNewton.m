%% End Point by Newton's Method

if exist('intval','file') && isintval(a)
    a = mid(a); b = mid(b); sigma = mid(sigma); eps = mid(eps); nu = mid(nu);
end

figure(1)
clf(1,'reset')
plot_cos(U(1:N),a,b,100,'r--',1)    
hold on
plot_cos(U(N+1:2*N),a,b,100,'b',1)
xlabel('$x$', 'Interpreter', 'latex')
legend('u','v')
title('Perturbation of trivial state')
set(gca,'FontSize',20)
axis square

it_max = 200;
tol = 10^-12;
K=30;

F_DF = @(X) F_DF_diffusion_croise(X,a,b,sigma,eps,nu,func_opt,which_gamma,K);
[U_refine,E] = func_Newton(U,F_DF,it_max,tol);


figure(2)
plot_cos(U_refine(1:N),a,b,100,'r--',2)
hold on
plot_cos(U_refine(N+1:2*N),a,b,100,'b',2)

xlabel('$x$', 'Interpreter', 'latex')
legend('u','v')
title("Numerical solution")
set(gca,'FontSize',20)
axis square

figure(3)
clf(3,'reset')
hold on
loglog(E(1:length(E)-1),E(2:length(E)),'bo')
loglog(E,E,'r--')
loglog(E,E.^2,'g--')
loglog(E,E.^3,'c--')

xlabel('e_n')
ylabel('e_{n+1}')
legend('Error','Linear','Quadratic','Cubic')
title("Convergence of the error in Newton's method")