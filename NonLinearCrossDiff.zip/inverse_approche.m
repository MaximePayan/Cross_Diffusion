function [A,w11,w12] = inverse_approche(A_bar,N,D,gv,gpv,u,Lap_inv,eps)
one = eye(2*N-1,1);
Zeros = zeros(2*D,2*D);
if exist('intval','file')
    one = intval(one);
    Zeros = intval(Zeros);
end
w11 = convomat(gv,2*N-1)\one; %size 2N-1
w12 = -convo(w11,convo(gpv,u,2*N-1))/eps; %size 2N-1

A=Zeros; %size 2D*2D
A11 = convomat(w11,D)*Lap_inv; %size D*D
A11(1:2*N-1,1:2*N-1) = A_bar(1:2*N-1,1:2*N-1);
A12 = convomat(w12,D)*Lap_inv;    
A12(1:2*N-1,1:2*N-1) = A_bar(1:2*N-1,2*N:4*N-2);
A21 = Zeros(1:D,1:D);
A21(1:2*N-1,1:2*N-1) = A_bar(2*N:4*N-2,1:2*N-1);
A22 = Lap_inv/eps;
A22(1:2*N-1,1:2*N-1) = A_bar(2*N:4*N-2,2*N:4*N-2);

A(1:D,1:D) = A11;
A(1:D,D+1:2*D) = A12;
A(D+1:2*D,1:D) = A21;
A(D+1:2*D,D+1:2*D) = A22;
end