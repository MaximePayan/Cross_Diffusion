function [Pnum,Pden]=frac_pol_derivatives(P,Q,order)
%%%Compute the order-derivatives of P/Q with simplifiactions : d(P/Q)/dx^order, return the
%%%numerator and the denominator of the fractional
degP = length(P)-1;
degQ = length(Q)-1;
if order==0
    Pnum =P;Pden=Q;
elseif order>=1 && order<=3
    Pp = polynomial_derivative(P);
    Qp = polynomial_derivative(Q);
    if order==1
        Pnum = conv(Pp,Q) - conv(Qp,P);
        Pden = conv(Q,Q);
        return
    end
    Ppp = polynomial_derivative(Pp);
    Qpp = polynomial_derivative(Qp);
    Q2 = conv(Q,Q);
    Qp2 = conv(Qp,Qp);
    if order==2
        Pnum1 = conv(Ppp,Q2); 
        Pnum21 = 2*conv(Pp,Qp); Pnum22 = conv(P,Qpp);
        n2 = max([length(Pnum21) length(Pnum22)]);
        Pnum2 = -conv(Q,[Pnum21,zeros(n2-length(Pnum21),1)]+[Pnum22,zeros(n2-length(Pnum22),1)]);
        Pnum3 = 2*conv(P,Qp2);
        n = max([length(Pnum1) length(Pnum2) length(Pnum3)]);
        Pnum = [Pnum1,zeros(1,n-length(Pnum1))]+[Pnum2,zeros(1,n-length(Pnum2))]...
            +[Pnum3,zeros(1,n-length(Pnum3))];
        Pden = conv(Q2,Q);
        return
    end
    Pppp = polynomial_derivative(Ppp);
    Qppp = polynomial_derivative(Qpp);
    Q3 = conv(Q2,Q);
    Qp3 = conv(Qp2,Qp);
    if order==3
        Pnum1 = conv(Pppp,Q3);
        Pnum2 = 6*conv(conv(Q,Qp),conv(Pp,Qp)+conv(P,Qpp));
        Pnum31 = 3*conv(Ppp,Qp);
        Pnum32 = 3*conv(Pp,Qpp);
        Pnum33 = conv(P,Qppp);
        n3 = max([length(Pnum31) length(Pnum32) length(Pnum33)]);
        Pnum3 = -conv(Q2,[Pnum31,zeros(1,n3-length(Pnum31))]+[Pnum32,zeros(1,n3-length(Pnum32))]...
            +[Pnum33,zeros(1,n3-length(Pnum33))]);
        Pnum4 = -6*conv(P,Qp3);
        n = max([length(Pnum1) length(Pnum2) length(Pnum3) length(Pnum4)]);
        Pnum = [Pnum1,zeros(1,n-length(Pnum1))]+[Pnum2,zeros(1,n-length(Pnum2))]...
            +[Pnum3,zeros(1,n-length(Pnum3))]+[Pnum4,zeros(1,n-length(Pnum4))];
        Pden = conv(Q3,Q);
        return
    end
else
    error('order is greater than 3, this case is not needed')
end
end

    
        