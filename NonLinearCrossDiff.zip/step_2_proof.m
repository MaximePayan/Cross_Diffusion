%Here we compute constants that determine the existence or not of a
%theoritical solution near U_refine
%IT'S NEEDED TO COMPUTE BY YOURSELF F,DF and D2F and put it in a function
%F_DF_D2F(u,v,gv,gpv,gppv,a,b,sigma,eps)


%% Computation on gamma

N = length(U_refine)/2;
u=U_refine(1:N);
v=U_refine(N+1:2*N);

if exist('intval','file')
    fprintf('\nRigorous validation with interval arithmetic\n')
    ipi = intval('pi');
    a=intval(a);b=intval(b);
    u = intval(u); v = intval(v); %size N
else
    fprintf('\nPrevalidation without interval arithmetic\n')
    ipi = pi;
end

[gammav,gammapv,gammappv,gammapppv,errgammav,errgammapv, ...
    errgammappv,errgammapppv] = transform_gamma(v,nu,func_opt,which_gamma,N,N,K);

if errgammapppv>1e2
    disp('Need to increase K for this v')
end

%% definition of A

D = DK + 4*(N-1);
one = eye(D,1);
Zeros = zeros(D,1);

[F_ext, DF_ext, D2F_ext] = F_DF_D2F(u,v,gammav,gammapv,gammappv,N,D,a,b,sigma,eps);
%sizes : 2D, 2Dx2D, 2Dx2

A_bar = inv(DF_ext([1:2*(2*N-1),D+(1:2*(2*N-1))],[1:2*(2*N-1),D+(1:2*(2*N-1))])); %size 4(2N-1)x4(2N-1)
A_bar = A_bar([1:(2*N-1),2*(2*N-1)+(1:2*N-1)],[1:2*N-1,2*(2*N-1)+(1:2*N-1)]); %size 2(2N-1)x2(2N-1)

% A_bar = inv(DF_ext([1:(2*N-1),D+(1:(2*N-1))],[1:(2*N-1),D+(1:(2*N-1))]));

if exist('intval','file')
    A_bar=intval(A_bar);
    one = intval(one);
    Zeros = intval(Zeros);
    eps = intval(eps);
    l = intval(l);
end

Lap_inv = laplacien_inv(D,l,true);

[A,w11,w12] = inverse_approche(A_bar,N,D,gammav,gammapv,u,Lap_inv,eps);

w21 = Zeros(1:2*N-1);
w22 = one(1:2*N-1)/eps;

%% Calculation of Y
Lap = laplacien(2*N-1,l,true);
A11Lap = A(1:2*N-1,1:2*N-1)*Lap;
normeA11Lap = norme_nu(A11Lap,nu,true);
A21Lap = A(D+(1:2*N-1),1:2*N-1)*Lap;
normeA21Lap = norme_nu(A21Lap,nu,true);
normeu = norme_nu(u,nu);
Y = norme_nu(A(:,1:2*N-1)*F_ext(1:2*N-1),nu) + norme_nu(A(:,D+(1:2*N-1))*F_ext(D+(1:2*N-1)),nu) ...
    + (normeA11Lap+normeA21Lap)*normeu*errgammav;

if exist('intval','file')
    disp(['Y = ',mat2str(infsup(Y))])
else
    disp(['Y = ',num2str(Y)])
end


%% Calculation of Z1
B = zeros(2*D,2*DK);
B(1:DK,1:DK) = eye(DK);
B(D+(1:DK),DK+(1:DK)) = eye(DK);

B = B - A(:,[1:DK+2*(N-1),D+(1:DK+2*(N-1))])*DF_ext([1:DK+2*(N-1),D+(1:DK+2*(N-1))],[1:DK, D + (1:DK)]);

B11 = B(1:D,1:DK);
B12 = B(1:D,DK+(1:DK));
B21 = B(D+1:2*D,1:DK);
B22 = B(D+1:2*D,DK+(1:DK));

cZ1 = zeros(DK,1);
dZ1 = zeros(DK,1);
k = ksi(DK,nu);

if exist('intval','file')
    cZ1=intval(cZ1);
    dZ1=intval(dZ1);
    k=intval(k);
end

for i=1:DK
    cZ1(i) = (norme_nu(B11(:,i),nu) + norme_nu(B21(:,i),nu))/k(i);
    dZ1(i) = (norme_nu(B12(:,i),nu) + norme_nu(B22(:,i),nu))/k(i);
end
% for i=1:DK
%     cZ1(i) = max(norme_nu(B11(:,i),nu)+norme_nu(B12(:,i),nu), norme_nu(B21(:,i),nu) + norme_nu(B22(:,i),nu))/k(i);
% end

c = l^2/((DK+1)*ipi)^2;
normeW = max(norme_nu(w11,nu)+norme_nu(w21,nu),norme_nu(w21,nu)+norme_nu(w22,nu));
Z1_a = max([cZ1; dZ1]);

Z1_b1 = max(norme_nu(one(1:2*N-1)-convo(w11,gammav,2*N-1),nu),norme_nu(convo(w11,convo(gammapv,u,2*N-1))+eps*w12,nu));
Z1_b2 = normeW*max(errgammav,norme_nu(u,nu)*errgammapv);
Z1_b3 = normeW*c*sigma*(norme_nu(one(1:N)-2*u,nu)+1);

Z1 = max(Z1_a,Z1_b1+Z1_b2+Z1_b3) + (normeA11Lap+normeA21Lap)*(errgammav+errgammapv*normeu);

if exist('intval','file')
    disp(['Z1 = ',mat2str(infsup(Z1))])
else
    disp(['Z1 = ',num2str(Z1)])
end
 

%% Calculation of Z2 (need to be in the neighborhood of (u,v), radius = r)

G2 = local_bound_on_gamma(v,r,func_opt,which_gamma,2,nu);
G3 = local_bound_on_gamma(v,r,func_opt,which_gamma,3,nu);

Z2_a = (normeA11Lap+normeA21Lap)*(norme_nu(gammapv,nu) + errgammapv + G2*r);

Z2_b =(normeA11Lap + normeA21Lap)*(norme_nu(convo(gammappv,u,2*N-1),nu)+ ... 
    normeu*(errgammappv + G3*r) + (norme_nu(gammappv,nu) +errgammappv +G3*r)*r);

normeA11 = norme_nu(A(1:D,1:D),nu,true);
normeA21 = norme_nu(A(D+1:end,1:D),nu,true);

Z2_c = 2*sigma*(norme_nu(A(:,1:N)*u,nu)+norme_nu(A(:,D+(1:N))*v,nu)...
    + (normeA11 + normeA21)*r);

Z2 = max([Z2_a Z2_b Z2_c]);

if exist('intval','file')
    disp(['Z2 = ',mat2str(infsup(Z2))])
else
    disp(['Z2 = ',num2str(Z2)])
end

clearvars gppv_ext gpv_ext A11 A21
if Z1 < 1
    disp 'Z1 < 1 : ok'
else
    disp 'Z1 >= 1 : not good'
end

test1 = 2*Y*Z2;
test2 = (1-Z1)^2;
if exist('intval','file')
    disp(['2Y*Z2 = ',mat2str(infsup(test1))])
    disp(['(1-Z1)^2 = ',mat2str(infsup(test2))])    
else
    disp(['2Y*Z2 = ',num2str(test1)])
    disp(['(1-Z1)^2 = ',num2str(test2)])
end

if test1 < test2
    disp '2Y*Z2 < (1-Z1)^2 : ok'
    r_min = (1-Z1 - sqrt(test2-test1))/Z2;
    r_max = (1-Z1)/Z2;
    if r_min<=r && r<r_max
        disp(['r=',mat2str(r), ', satisfying the hypothesis'])
    else
        disp(['r=',mat2str(r), ', must be lower'])
    end
    if exist('intval','file')
        disp(['r_min = ',mat2str(infsup(r_min))])
        disp(['r_max = ',mat2str(infsup(r_max))])    
    else
        disp(['r_min = ',num2str(r_min)])
        disp(['r_max = ',num2str(r_max)])
    end
else
    disp '2Y*Z2 >= (1-Z1)^2 : not good'
end
%%
clear A A11Lap A21Lap A_bar B D D2F_ext DF_ext errgammapppv errgammappv errgammapv errgammav
clear G2 G3  invDF normeA11 normeA21 F_ext gammapppv gammappv gammapv gammav k
clear normeA11Lap normeA21Lap normeu u u_ext v v_ext w11 w12 w21 w22 Z2_a Z2_b Z2_c Zeros
clear r_max r_min test1 test2 normeW cZ1 dZ1 B11 B12 B21 B22 c Lap Lap_inv one Z1_a Z1_b1 Z1_b2 Z1_b3