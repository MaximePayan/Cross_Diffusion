Sigma = UU(1,1:end);
UU0 = UU(2,:)+2*sum(UU(3:N+1,:),1);
VV0 = UU(N+2,:)+2*sum(UU(N+3:end,:),1);
norm2UU = zeros(length(UU),1);
norm2VV = zeros(length(UU),1);

B0 = Bifurcations(2,:) + 2*sum(Bifurcations(3:N+1,:),1);
Bs = Bifurcations(1,abs(B0)<10);
B0 = B0(abs(B0)<10);
norm2BBU = zeros(length(Bs),1);
norm2BBV = zeros(length(Bs),1);
for i=1:length(Bs)
    norm2BBU(i)=norm(Bifurcations(2:N+1,i));
    norm2BBV(i)=norm(Bifurcations(N+2:end,i));
end
l=b-a;
nx=400;
x=linspace(a,b,nx);
YY=zeros(length(UU),nx);
BB=zeros(length(Bs),nx);
for j=1:nx
    for i=1:size(UU,2)
        YY(i,j)=Fourier_cos(UU(2:N+1,i),x(j),l);
    end
    for i=1:length(Bs)
        BB(i,j)=Fourier_cos(Bifurcations(2:N+1,i),x(j),l);
    end
end

II = [];
for i=1:size(UU,2)
    norm2UU(i)=norm(UU(2:N+1,i));
    norm2VV(i)=norm(UU(N+2:end,i));
    if Sigma(i)>1e-6 && Sigma(i)<1 && abs(UU0(i)-1)<5
        II = [II,i];
    end
end
Spoints = bifurc_points_11(func_opt{1},func_opt{2},eps,b-a,false);
%%
figure(5)
clf(5,'reset')
plot(Bs(1,:),B0,'r+',Sigma(II),UU0(II),'b.',Spoints,ones(length(Spoints)),'r*',MarkerSize=10,LineWidth=2)
xlabel('\sigma','Rotation',0,'FontSize',18,'VerticalAlignment','bottom');
ylabel('u(0)','Rotation',0,'FontSize',18,'VerticalAlignment','cap');
legend('Bifurcation points numerically detected','numerical solution','Bifurcation points theoriticaly detected','Fontsize',15)
axis([0 0.65 0 4])
title('Numerical Staionary States','FontSize',20)
%%
figure(5)
clf(5,"reset")
plot(Sigma(II),norm2UU(II),'b.',Bs(1,:),norm2BBU,'ro')
xlabel('\sigma','Rotation',0,'FontSize',18,'VerticalAlignment','bottom');
ylabel('||u||_2','Rotation',0,'FontSize',18,'VerticalAlignment','cap');

figure(6)
clf(6,"reset")
plot(Sigma(II),norm2VV(II),'b.',Bs(1,:),norm2BBV,'ro')
xlabel('\sigma','Rotation',0,'FontSize',18,'VerticalAlignment','bottom');
ylabel('||v||_2','Rotation',0,'FontSize',18,'VerticalAlignment','cap');
%%
figure(7)
clf(7,'reset')
f=plot(Sigma,YY(:,1),'b.',MarkerSize=10,LineWidth=2);
xlabel('\sigma','Rotation',0,'FontSize',20,'FontWeight','bold','VerticalAlignment','bottom');
ylabel('u(x)','Rotation',0,'FontSize',20,'FontWeight','bold','VerticalAlignment','cap');
hold on
g=plot(Bs,BB(:,1),'r+',MarkerSize=10,LineWidth=2);
legend('Numerical solution','Bifurcation points numerically detected','Fontsize',20)
axis([0 0.65 0.3 3.7])
F(nx)=struct('cdata',[],'colormap',[]);
for i=1:nx
    f.YData=YY(:,i);
    hold on
    g.YData=BB(:,i);
    axis([0 0.65 0.3 3.7])
    title("x="+num2str(x(i)),'Fontsize',20);
    drawnow
    pause(0.02)
    F(i)=getframe(gcf);
    imwrite(F(i).cdata,"diagram-"+i+".png")
end
%%
Itrue=[];
Ifalse=[];
Inocvg=[];
for ii=1:length(theorem)
    if theorem(ii,2)==1
        Itrue=[Itrue,theorem(ii,1)];
    elseif theorem(ii,2)==0
        Ifalse=[Ifalse,theorem(ii,1)];
    else
        Inocvg=[Inocvg,theorem(ii,1)];
    end
end

%%
UU0_refine = UU_refine2(2,:)+2*sum(UU_refine2(3:N+1,:),1);
figure(4)
clf(4,'reset')
%plot(Bs(1,:),B0,'ro')
plot(Sigma(II),UU0_refine(II),'.',Sigma(Ifalse),UU0_refine(Ifalse),'ro',Sigma(Inocvg),UU0_refine(Inocvg),'bo',Sigma(Itrue),UU0_refine(Itrue),'go')
%plot(Sigma(II),UU0(II),'.',Sigma(Ifalse(65:66)),UU0(Ifalse(65:66)),'ro')
xlabel('\sigma','Rotation',0,'FontSize',18,'VerticalAlignment','bottom');
ylabel('u(0)','Rotation',0,'FontSize',18,'VerticalAlignment','cap');
hold on
scatter(Sigma(II),UU0(II),'square','SizeData',100,'LineWidth',0.5,'MarkerEdgeColor',"#7E2F8E", ...
    'MarkerEdgeAlpha',0.1)
legend('end','false','true','start')
hold on
%func_opt={@(x) g_fr(x,P,Q,n),@(x) g_fr_prime(x,P,Q,n)};
% Spoints = bifurc_points_11(func_opt{1},func_opt{2},eps,b-a,false);
% plot(Spoints,ones(length(Spoints)),'r*',MarkerSize=10)
axis([0 0.65 0.4 2]);
%legend('points de bifurcation autour de (1,1)')
title('Etats stationnaires obtenus par continuation numérique','FontSize',20)
subtitle('Vérification des hypothèses du théorème','FontSize',18)