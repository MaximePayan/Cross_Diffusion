function [F,DF] = F_DF_diffusion_croise(U,a,b,sigma,eps,nu,func_opt,which_gamma,K)
% be careful func_opt = {g gp gpp gppp ...}

N = length(U)/2;
u = U(1:N);
v = U(N+1:2*N);
l = b-a;

Mu = convomat(u);

[gv,gpv]=transform_gamma(v,nu,func_opt,which_gamma,N,N,K);

Mgv = convomat(gv);
Mgpv = convomat(gpv);
uu = Mu*u;
ugv = Mu*gv;
Lap = laplacien(N,l);
I = eye(N);

F1 = Lap.*ugv + sigma*(u-uu);
F2 = eps*Lap.*v +u-v;

F = [F1;F2];

DF = [diag(Lap)*Mgv + sigma*(I-2*Mu), diag(Lap)*Mgpv*Mu;
    I, eps*diag(Lap)-I];
end
