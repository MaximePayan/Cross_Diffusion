function G = local_bound_on_gamma(v,r,func_opt,which_gamma,order,nu)
%%% Give an upper bound on norme_nu(f . ,nu) on the ball of center v,
%%% radius R


if which_gamma == "frac_2"
    which_gamma = "frac";

end

switch which_gamma
    case "exp"
        alpha = func_opt{end};
        G = abs(alpha)^order*func_opt{1}((norme_nu(v,nu)+r));
    case "frac"
        P=func_opt{end-1};Q=func_opt{end};
        [P,Q]=frac_pol_derivatives(P,Q,order);
        G = g_frac(norme_nu(v,nu)+r,abs(P),1);
        [~,Qv] = vectors_PvQv(v,P,Q,length(v));
        one = zeros(size(v));
        one(1) = 1;
        a = convomat(Qv)\one;
        q1 = norme_nu(convo(a,Qv)-one,nu);
        if q1 >=1
            error('Qv is not invertible')
        end
        Qp = polynomial_derivative(Q);
        q2 = norme_nu(a,nu)*g_frac(norme_nu(v,nu)+r,abs(Qp),1);
        if r >= (1-q1)/q2
            disp(['r must be lower than ',num2str(inf((1-q1)/q2))])
            G = Inf;
            return
        end
        G = norme_nu(a,nu)*G/(1-q1-q2*r);
end

end