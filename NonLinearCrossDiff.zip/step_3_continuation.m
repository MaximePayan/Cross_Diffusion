%% Acquisition of a large number of solution, using continuation.
%Start from the last solution obtained or start from the point [0 one one]
%with the direction 'go to the right'.

if exist('intval','file') && isintval(a)
    a = mid(a); b = mid(b); sigma = mid(sigma); eps = mid(eps); nu = mid(nu);
end

%Up=[sigma;U_refine]; 
U0=zeros(2*N,1);U0(1)=1;U0(N+1)=1;
Up=[0.001;U0];
Vp=zeros(2*N+1,1);
Vp(1)=1;

K=30;

ds=3e-3;
itmax=10;
p=2;
Bifurcations = [Up];
func_G_DG = @(U_tilde,U1,V1,s) G_DG(U_tilde,U1,V1,a,b,eps,nu,s,func_opt,which_gamma,K);
tic
[UU,it,Bifurcations]=func_test_continuation_bis(Up,Vp,ds,func_G_DG,p,itmax,0,Bifurcations);
toc
