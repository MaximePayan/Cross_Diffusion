function y = g_frac(x,Pnum,Pden)
%Polynomes are represented by the list of there coeff
%Pnum the numerator polynomial, Pden the denominator polynomial
Xnum = x'.^(0:length(Pnum)-1);
Xden = x'.^(0:length(Pden)-1);
y = Pnum*Xnum'./(Pden*Xden');
end