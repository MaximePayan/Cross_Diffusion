it_max = 200;
tol = 1e-15;

% load('initialized_data_exp.mat')
% load('big_data_exp_unverified.mat')
%UU must be set that contains all the numerical
%solutions that we want to validate, UU_refine will be the what we get in
%the final process and what has been truly validate or not. (The
%Newton's method applied can change the approximate solution)

Sigma = UU(1,1:end);
UU0 = UU(2,:)+2*sum(UU(3:N+1,:),1);

%%
II = [];
for i=1:length(UU)
    if Sigma(i)>1e-6 && abs(UU0(i)-1)<5 %almost all except the lines y=1 and x=0
        II = [II,i];
    end
end
%%
K=30; %number of terms in the power series
N_out = N;
r = 1e-5;
DK = 2*N_out;
%UU_refine = zeros(2*N_out+1,length(UU));

Itrue=[];
Ifalse=[];
Inocvg=[];
%%
for ii=1:length(II)
    nbpoint = II(ii);
    U = UU(2:end,nbpoint);
    sigma = UU(1,nbpoint);
    U_refine = [U(1:N);zeros(N_out-N,1);U(N+1:end);zeros(N_out-N,1)];
%     %step 1 If you need to refine data of UU
%     F_DF = @(X) F_DF_diffusion_croise(X,a,b,sigma,eps,nu,func_opt,which_gamma,K);
%     [U_refine,~] = func_Newton(U_refine,F_DF,it_max,tol);
%     UU_refine(:,nbpoint)=[sigma ; U_refine];
    %step 2
    tic
    step_2_proof
    %check hypothesis
    if not(Z1 < 1 && 2*Y*Z2 < (1-Z1)^2) %constants, are they good ?
        Ifalse = [Ifalse;nbpoint];
    elseif not(abs(r-(1-Z1)/Z2)<sqrt(test2-test1))%neighboorhood, is it good ? 
        Inocvg = [Inocvg;nbpoint];
    else %if the answers are yes ! The theorem is true for this one !
        Itrue = [Itrue;nbpoint];
    end
    disp(ii)
    toc
end


%% Plots
 
%UU0_refine = UU_refine(2,:)+2*sum(UU_refine(3:N+1,:),1);

figure(4)
clf(4,'reset')
plot(Sigma(II),UU0(II),'.',Sigma(Ifalse),UU0(Ifalse),'ro', Sigma(Itrue),UU0(Itrue),'go')
hold on
%scatter(Sigma(II),UU0_refine(II),'square','SizeData',100,'LineWidth',0.5,'MarkerEdgeColor',"#7E2F8E", ...
 %   'MarkerEdgeAlpha',0.1)
legend('end','false','true','start')
xlabel('\sigma','Rotation',0,'FontSize',18,'VerticalAlignment','bottom');
ylabel('u(0)','Rotation',0,'FontSize',18,'VerticalAlignment','cap');
%axis([0 0.3 0 2.25])
%legend('solution numérique','point non validé','point validé','FontSize',18)
title('Etats stationnaires obtenus par continuation numérique','FontSize',20)
subtitle('Vérification des hypothèses du théorème','FontSize',18)

%% Refinement
Itrue2 =[];
Ifalse2=[];
%%
K= 30; %number of terms in the power series
N = 50;
N_out = 100;
DK = 2*N_out;
tol = 1e-15;
it_max = 10;
r=1e-8;
UU_refine = zeros(2*N_out+1,length(UU));
UU_refine([1:N+1,1+N_out+(1:N)],1:length(UU)) = UU(:,1:length(UU));
% tmp =zeros(2*N_out+1,length(UU));
% tmp([1:N+1,1+N_out+(1:N)],1:length(UU)) = UU(:,1:length(UU));
% tmp(:,1:length(UU_refine)) = UU_refine;
% UU_refine = tmp;
%%
for ii=1:length(Ifalse)
    nbpoint = Ifalse(ii);
    U = UU_refine(2:end,nbpoint);
    %N = length(UU(2:end,nbpoint))/2;
    sigma = UU_refine(1,nbpoint);
    if exist('intval','file') && isintval(a)
        a = mid(a); b = mid(b); sigma = mid(sigma); eps = mid(eps); nu = mid(nu);
    end
    %step 1
    tic
    F_DF = @(X) F_DF_diffusion_croise(X,a,b,sigma,eps,nu,func_opt,which_gamma,K);
    [U_refine,E] = func_Newton(U,F_DF,it_max,tol);
    UU_refine(2:end,nbpoint) =  U_refine;
    %step 2
    
    step_2_proof

    if Z1 < 1 && 2*Y*Z2 < (1-Z1)^2
        Itrue2 = [Itrue2,nbpoint];
    else
        Ifalse2 = [Ifalse2,nbpoint];
    end
    disp(ii)
    toc
end
%%      
Sigma = UU(1,1:end);
N=50;
UU0 = UU(2,:)+2*sum(UU(3:N+1,:),1);
UU0_refine2 = UU_refine(2,:)+2*sum(UU_refine(3:N_out+1,:),1);
figure(4)
clf(4,'reset')
plot(Sigma(II),UU0_refine2(II),'.',Sigma(Ifalse2),UU0_refine2(Ifalse2),'ro', Sigma(Itrue),UU0_refine2(Itrue),'go')
hold on
plot(Sigma(Itrue2),UU0(Itrue2),LineStyle="none",Marker="o",Color="green")
hold on
% scatter(Sigma(II),UU0_refine2(II),'square','SizeData',100,'LineWidth',0.5,'MarkerEdgeColor',"#7E2F8E",...
%     'MarkerEdgeAlpha',0.1)
legend('data','false','true')
xlabel('\sigma','Rotation',0,'FontSize',18,'VerticalAlignment','bottom');
ylabel('u(0)','Rotation',0,'FontSize',18,'VerticalAlignment','cap');
axis([0 0.65 0.4 3.7]);
%legend('solution numérique','point non validé','point validé','FontSize',18)
title('Stationary States obtained by Numerical continuation','FontSize',20)
subtitle('Proofs of theorems','FontSize',18)