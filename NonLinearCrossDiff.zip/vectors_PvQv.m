function [Pv,Qv] = vectors_PvQv(v,P,Q,D)
% v is a vector contains fourier's coeff, return fourier's coeff of the
% functions P(v(.)) and Q(v(.)) using the polynomials and the
% Banach algebra.
%If you need exact computation of Pv,Qv without truncation, D must be
%greater than (lenght(v)-1)*n+1, also D>=length(v)
n = max(length(P),length(Q));
Pbar = zeros(D,1);
Qbar = zeros(D,1);
Pbar(1)=P(1);
Qbar(1)=Q(1);
if exist('intval','file') && isintval(v)
    Pbar = intval(Pbar);
    Qbar = intval(Qbar);
end
ws=[v;zeros(D-length(v),1)];
Mw=convomat(ws);
i=1;
while i<n
    if i<length(P)
        Pbar = Pbar + P(i+1)*ws;
    end
    if i<length(Q)
        Qbar = Qbar + Q(i+1)*ws;
    end
    ws=Mw*ws;
    i=i+1;
end
Pv = Pbar;
Qv = Qbar;
end


