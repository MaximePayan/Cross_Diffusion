function [y] = g_exp(alpha,x)
y = exp(alpha*x);
end